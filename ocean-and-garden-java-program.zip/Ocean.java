import java.util.*;
public class Ocean{
    public static void main(String[] args){
        Scanner ps = new Scanner(System.in);
        String[] s = ps.next().replace("]","").replace("[","").split(",");
        int l = 1;
        TreeSet<Integer> t1 = new TreeSet<>();
        TreeSet<Integer> t2 = new TreeSet<>();
        t1.add(s.length-1);
        t2.add(0);
        for(int i = 0;i<s.length-1;i++){
             if(Integer.parseInt(s[i])>Integer.parseInt(s[i+1])){
                 t1.add(i);
             }
             if (Integer.parseInt(s[l]) > Integer.parseInt(s[l-1])){
             t2.add(l-1);
             }
             l++;
        }
        System.out.println(t1.toString().replace(" ","")+"\n"+t2.toString().replace(" ",""));
    }
}